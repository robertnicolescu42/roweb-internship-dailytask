﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your Javascript code.

const uri = 'http://localhost:63868/api/AlbumTracker/';
let albums = [];

function getItems() {
    fetch(uri)
        .then(response => response.json())
        .then(data => _displayItems(data))
        .catch(error => console.error('Unable to get items.', error));
}

function _displayItems(data) {
    const tBody = document.getElementById('albums');
    tBody.innerHTML = '';
    const button = document.createElement('button');

    data.forEach(item => {

        let deleteButton = button.cloneNode(false);
        deleteButton.innerText = 'Delete';
        deleteButton.setAttribute('onclick', `deleteItem(${item.albumID})`);
        deleteButton.id = "deletebutton";
        

        let editButton = button.cloneNode(false);
        editButton.innerText = 'Edit';
        editButton.addEventListener("click", function () {
            $('#exampleModal').modal('show')
        });
        editButton.setAttribute('onclick', `displayEditForm(${item.albumID})`);
        editButton.id = "editbutton";

        let tr = tBody.insertRow();

        let td1 = tr.insertCell(0);
        let albumName = document.createTextNode(item.albumName);
        td1.appendChild(albumName);

        let td2 = tr.insertCell(1);
        let artistName = document.createTextNode(item.artistName);
        td2.appendChild(artistName);

        let td3 = tr.insertCell(2);
        let albumDescription = document.createTextNode(item.albumDescription);
        td3.appendChild(albumDescription);

        let td4 = tr.insertCell(3);
        let albumRating = document.createTextNode(item.albumRating);
        td4.appendChild(albumRating);

        let td5 = tr.insertCell(4);
        let albumYear = document.createTextNode(item.albumYear);
        td5.appendChild(albumYear);

        let td6 = tr.insertCell(5);
        td6.appendChild(editButton);

        let td7 = tr.insertCell(6);
        td7.appendChild(deleteButton);


    });

        //document.getElementById("editbutton").className = "btn btn-light";
        //document.getElementById("deletebutton").className = "btn btn-light";

    albums = data;
}

function addItem() {
    const addAlbumName = document.getElementById('InputAlbumName').value;
    const addArtist = document.getElementById('InputArtist').value;
    const addDescription = document.getElementById('InputDescription').value;
    const addRating = parseInt(document.getElementById('InputRating').value, 10);
    const addYear = parseInt(document.getElementById('InputYear').value, 10);
    //problema aici e ca json.stringify scoate int-urile ca si stringuri (cred) [rezolvat]

    const item = {
        albumName: addAlbumName,
        artistName: addArtist,
        albumDescription: addDescription,
        albumRating: addRating,
        albumYear: addYear
    };

    fetch(uri, {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(item)
    })
    //.then(response => response.json())
    //.catch(error => console.error('Unable to add item.', error));
}

function deleteItem(id) {
    fetch(`${uri}${id}`, {
        method: 'DELETE'
    })
        .then(() => getItems())
        .catch(error => console.error('Unable to delete item.', error));
}

function updateItem() {
    debugger;
    const updateAlbumName = document.getElementById('edit-name').value;
    const updateAlbumDescription = document.getElementById('edit-description').value;
    const updateArtistName = document.getElementById('edit-artistname').value;
    const updateRating = parseInt(document.getElementById('edit-rating').value, 10);
    const updateYear = parseInt(document.getElementById('edit-year').value, 10);
    const itemId = document.getElementById('edit-id').value;



    const item = {
        albumID: parseInt(itemId, 10),
        albumName: updateAlbumName,
        artistName: updateArtistName,
        albumDescription: updateAlbumDescription,
        albumRating: updateRating,
        albumYear: updateYear
    };

    fetch(`${uri}${itemId}`, {
        method: 'PUT',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },

        body: JSON.stringify({
            AlbumID: item.albumID,
            ArtistName: item.artistName,
            AlbumName: item.albumName,
            AlbumDescription: item.albumDescription,
            AlbumRating: item.albumRating,
            AlbumYear: item.albumYear
        }
        )
    })
}

function displayEditForm(id) {

    const item = albums.find(item => item.albumID === id);
    document.getElementById('edit-id').value = item.albumID;
    document.getElementById('edit-name').value = item.albumName;
    document.getElementById('edit-description').value = item.albumDescription;
    document.getElementById('edit-artistname').value = item.artistName;
    document.getElementById('edit-rating').value = item.albumRating;
    document.getElementById('edit-year').value = item.albumYear;
}